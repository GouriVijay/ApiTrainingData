package endpoints;

public class Routes {
	public static String baseuri="https://petstore.swagger.io";  //base url
	public static String get_store="/v2/store/inventory";        //path for get method
	public static String post_placeOrder="/v2/store/order";      //path for post method
	public static String delete_order="/v2/store/order/3";       //path for delete method
	public static String get_byOrder="/v2/store/order/3";        //path of get method using orderid
	public static String baseUrii="https://petstore.swagger.io/v2/store/inventory";   //url for schema validation
}
