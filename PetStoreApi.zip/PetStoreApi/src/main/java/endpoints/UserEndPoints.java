package endpoints;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
//create to perform CRUD operations in user api
import payloads.PetStoreModel;

public class UserEndPoints {
	
	//get method in order to get details of store where id is passed as parameter
	public static Response getStore(long id) {  
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri) //base uri is passed in baseUri()
				.basePath(Routes.get_store) //path of get method is passed 
				.contentType("application/json") //content type is passed
				.accept(ContentType.JSON)
				.when()
				.get(); //get method
		return response; //return response of get method
	}
	
	
	//post method to place order where payload containing post details is passed as parameter
	public static Response postPlaceOrder(PetStoreModel payload) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.post_placeOrder)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post(); //post method is invoked
		return response;	
	}
	

	//method to get details based on order id
	public static Response getByOrderId(long id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.get_byOrder)
				.pathParam("OrderId", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}


	//method to delete an order
	public static Response deleteOrder(long id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.delete_order)
				.pathParam("OrderId", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.delete();  // delete method is invoked
		return response;
	}
	

}




