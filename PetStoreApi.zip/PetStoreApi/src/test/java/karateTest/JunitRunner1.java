package karateTest;
import com.intuit.karate.junit5.Karate;
public class JunitRunner1 {
	@Karate.Test
	Karate karateTest() {
		return Karate.run("classpath:karateTest/StoreTest.feature").relativeTo(getClass());
	}
}
