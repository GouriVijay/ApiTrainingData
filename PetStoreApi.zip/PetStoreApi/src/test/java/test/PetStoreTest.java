package test;

import static org.testng.Assert.assertEquals;
import java.io.File;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import endpoints.Routes;
import endpoints.UserEndPoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.PetStoreModel;

@Listeners(utilities.ExtentReportsListener.class) //to create report
public class PetStoreTest{

	public PetStoreModel storePayload;
	
	@BeforeClass
	public void setup() {
		storePayload=new PetStoreModel(1,101,1,"2024-05-02T09:12:24.439+0000","placed",true);
	}
	
	@Test
	public void getStore() {
		//get method will return pet inventories by status
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getStore(this.storePayload.getId());
		 response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void getByOrderId() {
//		get order details by specifying order id
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getByOrderId(this.storePayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);//assertion fails due to bug in the api. It is specified to provide order id between 1 to 10 but its showing 404 error
	}
	
	
	@Test
	public void deleteOrder() {
//		delete order based on id
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.deleteOrder(this.storePayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200); //assertion fails due to bug in the api. It is specified to provide order id between 1 to 10 but its showing 404 error
		 
	}
	
	@Test
	public void postPlaceOrder() {
		//post method will place an order
		PetStoreModel storePayload1=new PetStoreModel();
		storePayload1=new PetStoreModel(1,101,2,"2024-05-02T09:12:24.439Z","placed",true);
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.postPlaceOrder(storePayload1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	
	@Test
    public void schemavalidation() {
//		schema validation for validating response
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUrii)
	        .when()
	        .get()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\269657\\APItesting\\PetStoreApi\\src\\test\\resources\\payload\\sample.json")));
	}
}

