package endpoints;

public class Routes {
	public static String baseUri="http://localhost:8080/trainee";
	public static String postUser="/trainees";
	public static String get_allUsers="/all";
	public static String get_singleUser="/{id}";
	public static String putUser="/trainees/{id}";
	public static String patchUser="/trainees/{id}";
	public static String deleteUser="/trainees/{id}";
	public static String getUrii="/3";
}
