package endpoints;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.SlackModel;

public class SlackTeamEndpoints {
	
//	get all user response method
	public static Response getAllUsers() {
		Response response = RestAssured.given()
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_allUsers)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
//	get single user response method
	public static Response getSingleUser(int id) {
		Response response = RestAssured.given()
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_singleUser)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
//	response method to create new user
	public static Response createNewUser(SlackModel payload) {
		Response response = RestAssured.given()
				.headers(						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.postUser)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}

//	response method to update user
	public static Response update(int id, SlackModel payload) {
		
		Response response = RestAssured.given()
				.headers(						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.putUser)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
	
//	response method to update user
	public static Response update1(int id, File payload) {
		
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.putUser)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
	

//	public static Response updatePartial(int id, SlackModel payload) {
//		
//		Response response = RestAssured.given()
//				.headers(
//						
//						"Content-Type",
//						ContentType.JSON,
//						"Accept",
//						ContentType.JSON)
//				.baseUri(Routes.baseUri)
//				.basePath(Routes.putUser)
//				.pathParam("id", id)
//				.contentType("application/json")
//				.accept(ContentType.JSON)
//				.body(payload)
//				.when()
//				.patch();
//		return response;	
//	}
//	
	
	

//	response method to delete user
	public static Response delete(int id) {
		Response response = RestAssured.given()
			.headers(
					
					"Content-Type",
					ContentType.JSON,
					"Accept",
					ContentType.JSON)
			.baseUri(Routes.baseUri)
			.basePath(Routes.deleteUser)
			.pathParam("id", id)
			.contentType("application/json")
			.accept(ContentType.JSON)
			.when()
			.delete();
		return response;	
	}
	

}
