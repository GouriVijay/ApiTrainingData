package karate;

import com.intuit.karate.junit5.Karate;

public class junit5Runner {
	@Karate.Test
	Karate karatetest()
	{
		return Karate.run("classpath:karate/slackTeamKarate.feature").relativeTo(getClass());
	}
}
