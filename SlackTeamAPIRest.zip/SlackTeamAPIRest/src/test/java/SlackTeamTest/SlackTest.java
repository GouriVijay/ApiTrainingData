package SlackTeamTest;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.SlackTeamEndpoints;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.SlackModel;

@Listeners(utilities.ExtentReportsListener.class) //to create report
public class SlackTest {
	
	//method to get a user
	@Test(priority=1)
	public void getUser() {
		RestAssured.useRelaxedHTTPSValidation();
		SlackModel team=new SlackModel(153);
		Response response=SlackTeamEndpoints.getSingleUser(team.getId());
		response.then().log().all();
				
		assertEquals(response.getStatusCode(), 200);
		assertEquals(response.getContentType(),"application/json" );

	}
	
//	method to getAllUsers
	@Test(priority=2)
	public void getAllUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=SlackTeamEndpoints.getAllUsers();
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	method to create user
	@Test(priority=3)
	public void createNewUser() {
		RestAssured.useRelaxedHTTPSValidation();
		SlackModel s1=new SlackModel("braily","alex","braily@gmail.com","us");
		Response response=SlackTeamEndpoints.createNewUser(s1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
	
//	method to update user
	@Test(priority=5)
	public void putBook1() {
		File payload=new File("C:\\Users\\269657\\APItesting\\SlackTeamAPIRest\\src\\test\\resources\\payload\\data.json");
		RestAssured.useRelaxedHTTPSValidation();
		Response response=SlackTeamEndpoints.update1(153, payload);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	

//	Test method for delete a user
	@Test(priority=6)
	public void deleteUser() {
		RestAssured.useRelaxedHTTPSValidation();
		SlackModel team=new SlackModel(15);
		Response response=SlackTeamEndpoints.delete(team.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	
	//Test method for validating json schema for get user
	@Test(priority=7)
    public void schemaValidation() {
	 RestAssured.useRelaxedHTTPSValidation();
	 RestAssured.given()
	 	.baseUri(Routes.baseUri)
		.basePath(Routes.getUrii)
	    .when()
	    .get()
	    .then()
	    .assertThat()
	    .body(matchesJsonSchema(new File(System.getProperty("user.dir")+"/src/test/resources/payload/schema.json")));
	}
	
	


}
