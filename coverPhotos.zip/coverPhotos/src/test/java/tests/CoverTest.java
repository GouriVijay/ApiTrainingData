package tests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.UserEndPoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.CoverModel;

public class CoverTest {
	public CoverModel coverPayload;

	@BeforeClass
	public void setup() {
		coverPayload=new CoverModel(7,7,"https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 7&w=250&h=350");
	}
	@Test(priority = 1)
	public void getListOfCoverPhoto() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getListOfCoverPhotos(this.coverPayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);	//checks whether response status code is 200
		assertEquals(response.getContentType(), "application/json; charset=utf-8; v=1.0");	//checks whether response content type is json
	}

	@Test(priority = 2)
	public void getCoverById() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getById(this.coverPayload.getId());
		response.then().log().all()
		.assertThat().statusLine("HTTP/1.1 200 OK")
		.body("id", Matchers.is(7))	//checks if id in response body is 2
		.body("idBook", Matchers.is(7))	//checks if book id in response body is 1
		.body("url", Matchers.is("https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 7&w=250&h=350"));
		assertEquals(response.getStatusCode(), 200);
		assertEquals(response.getContentType(), "application/json; charset=utf-8; v=1.0");

	}

	@Test(priority = 3)
	public void getCoverByBookId() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getByBookId(this.coverPayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
		assertEquals(response.getContentType(), "application/json; charset=utf-8; v=1.0");
	}

	@Test(priority = 4)
	public void createCover() {
		CoverModel coverPayload1=new CoverModel();
		coverPayload1=new CoverModel(200,200,"https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.createCoverPhoto(coverPayload1);
		response.then().log().all()
		.body("id", Matchers.is(200))	//checks if id in response body is 6
		.body("idBook", Matchers.is(200))	//checks if book id in response body is 6
		.body("url", Matchers.is("https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"));
		assertEquals(response.getStatusCode(), 200);
		assertEquals(response.getContentType(), "application/json; charset=utf-8; v=1.0");
	}

	@Test(priority = 5)
	public void UpdateCover() {
		File payload= new File("C:\\Users\\269657\\APItesting\\coverPhotos\\src\\test\\resources\\payload\\putData.json");	//specifies the file path of json data for put request
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.updateCoverPhoto(10, payload);
		response.then().log().all()
		.body("id", Matchers.is(10))	//checks if id in response body is 10
		.body("idBook", Matchers.is(10))	//checks if book id in response body is 10
		.body("url", Matchers.is("https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"));
		assertEquals(response.getStatusCode(), 200);
		assertEquals(response.getContentType(), "application/json; charset=utf-8; v=1.0");
	}

	@Test(priority = 6, dependsOnMethods = "createCover")
	public void deleteAuthor() {
		Response response = UserEndPoints.deleteCoverPhoto(200);
		response.then().log().all()
		.assertThat().statusCode(200);
		
//		Assert.assertEquals(response.getStatusCode(), 200);
	}
	
	@Test(priority=7)
    public void schemavalidation() {
//		schema validation for validating response
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUri_for_schema_validation)
	        .when()
	        .get()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("src/test/resources/payload/schema.json")));
	}

}
