package endpoints;

public class Routes {
	public static String baseUri="https://fakerestapi.azurewebsites.net";
	public static String get_list="/api/v1/CoverPhotos";
	public static String get_byId="/api/v1/CoverPhotos/{id}";
	public static String get_byBookId="/api/v1/CoverPhotos/books/covers/{idBook}";
	public static String post_coverPhoto="/api/v1/CoverPhotos";
	public static String put_coverPhoto="/api/v1/CoverPhotos/{id}";
	public static String delete_coverPhoto="​/api​/v1​/CoverPhotos​/{id}";
	public static String baseUri_for_schema_validation="https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/7";
}
