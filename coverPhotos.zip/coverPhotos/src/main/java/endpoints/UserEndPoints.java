package endpoints;
import payloads.CoverModel;
import java.io.File;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
//methods to perform CRUD operations in author management api
public class UserEndPoints {
	public static Response createCoverPhoto(CoverModel payload) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,	//specifies content type as json
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)	
				.basePath(Routes.post_coverPhoto)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)	//payload contains the necessary data for post method
				.when()
				.post();
		return response;	//returns post method response
	}
	
	public static Response getById(long id) {
		Response response = RestAssured.given()
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_byId)
				.pathParam("id", id)	//specifies the id of the author
				.when()
				.get();
		return response;	//returns get method response
	}
	
	public static Response getByBookId(long id) {
		Response response = RestAssured.given()
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_byBookId)
				.pathParam("idBook", id)	//specifies the id of the book
				.when()
				.get();
		return response;	//returns get method response
	}	
	
	public static Response getListOfCoverPhotos(long id) {
		Response response = RestAssured.given()
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_list)
				.when()
				.get();
		return response; 	//returns get method response
	}
	
	public static Response deleteCoverPhoto(int id) {
		Response response = RestAssured.given()
				.baseUri(Routes.baseUri)
				.basePath(Routes.delete_coverPhoto)
				.pathParam("id", id)
				.when()
				.delete();
		
		return response;	//returns delete method response
	}
	
	public static Response updateCoverPhoto(long id,File payload) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.put_coverPhoto)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	//returns put method response
	}
}