package com.example.repository;

import com.example.model.Trainee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TraineeRepository extends JpaRepository<Trainee,Long> {
    List<Trainee> findByName(String firstname);
}
//repository interface is used to store trainees data in database using the following methods
/*
Methods used to store trainees data in database
save
findById
delete
findAll
 */
