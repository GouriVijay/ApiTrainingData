package payload;

public class AuthorModel {

	public int id;
	public int idbook;
	public String fname;
	public String lname;
	
	public AuthorModel(){
        
    }
	public AuthorModel(int id,int idbook,String fname,String lname){
		this.id = id;
		this.idbook = idbook;
		this.fname = fname;
		this.lname = lname;
	}
	public int getId() {
        return id;
    }
	public int getIdBook() {
		return idbook;
	}
	
	public String getfname() {
		return fname;
	}
	
	public String getlname() {
		return lname;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setIdBook(int idbook) {
        this.idbook = idbook;
    }
	
	public void setfname(String fname) {
        this.fname = fname;
    }
	
	public void setlname(String lname) {
		this.lname = lname;
	}
	
	
	@Override
	public String toString() {
        return "AuthorModel {id='" + id + "', idbook='" + idbook + "', fname='" + fname + "', lname='" + lname + "'}";
    }
}
