package utilities;

import org.testng.annotations.DataProvider;

public class DataProviders {

	@DataProvider(name = "Exceldata")
	public String[][] getData() {
		String path = System.getProperty("user.dir") + "//testdata//exceldata1.xlsx";
		String SheetName = "Sheet1";
        XLutility xl = new XLutility(path ,SheetName);
        int rowCount = xl.GetRowCount();
        int colCount = xl.GetCellCount(rowCount);
        String[][] arr = new String[rowCount][colCount];
        for(int i = 1; i<=rowCount; i++) {
        	for(int j = 0; j<colCount; j++) {
        		arr[i-1][j] = xl.GetCellData(i, j);
        	}
        }
        return arr;
        
	}
}
