package karatetestrunner;

import com.intuit.karate.junit5.Karate;

public class TestRunner {
	@Karate.Test
	Karate Karatetest() {
        return Karate.run("classpath:RestAssuredPractice.feature").relativeTo(getClass());
    }
}