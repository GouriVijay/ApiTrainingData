package testcase;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import endpoints.AuthorEndPoints;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import payload.AuthorModel;
import utilities.DataProviders;
import utilities.ExtentReportManager;
@Listeners(ExtentReportManager.class)	
public class AuthorTest {
	
	private Faker fake;
	private AuthorModel author;
	
	@BeforeClass
	public void setup() {
	fake = new Faker();
	author = new AuthorModel();
	author.setId(fake.number().numberBetween(1, 576));
	author.setIdBook(fake.number().numberBetween(1, 200));
	author.setfname(fake.name().firstName());
	author.setlname(fake.name().lastName());
	}
	@Test(priority = 0)
	public void testCreateAuthor() {
        Response response = AuthorEndPoints.createAuthor(author);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
	@Test(priority = 1)
	public void testgetAllAuthor() {
        Response response = AuthorEndPoints.getAllAuthor();
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
	@Test(priority = 2)
	public void testgetSingleAuthor() {
        Response response = AuthorEndPoints.getSingleAuthor(author.getId());
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
	@Test(priority = 3)
	public void testgetSingleAuthorWithBook() {
        Response response = AuthorEndPoints.getSingleAuthorWithBook(author.getIdBook());
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
	
	@Test(priority = 4)
	public void testUpdateAuthor() {
        Response response = AuthorEndPoints.updateAuthor(author,author.getId());
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
	@Test(priority = 5)
	public void testDeleteAuthor() {
        Response response = AuthorEndPoints.deleteAuthor(author.getId());
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
	@Test(priority = 6 , dataProvider ="Exceldata" , dataProviderClass = DataProviders.class)
	public void testCreateAuthorUsingExcel(String id1 , String bookid1 , String fname , String lname) {
        int id = Integer.parseInt(id1);
        int bookid = Integer.parseInt(bookid1);
        author = new AuthorModel();
        author.setId(id);
        author.setIdBook(bookid);
        author.setfname(fname);
        author.setlname(lname);
		Response response = AuthorEndPoints.createAuthor(author);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
	@Test(priority = 7)
	public void testSchemavalidation() {
		File f = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\AuthorSchema.json");
		for(int i =1;i<=576;i++) {
			Response response= AuthorEndPoints.getSingleAuthor(i);
            response.then().log().all()
            .assertThat()
            .body(JsonSchemaValidator.matchesJsonSchema(f));
		}
	}
}
