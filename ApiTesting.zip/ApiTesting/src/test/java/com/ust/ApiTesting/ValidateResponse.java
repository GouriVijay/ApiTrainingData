package com.ust.ApiTesting;

import static org.hamcrest.CoreMatchers.equalTo;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.ITestListener;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import utilities.ExtentReportsListener;
@Listeners(utilities.ExtentReportsListener.class)

public class ValidateResponse implements ITestListener{
	ExtentReportsListener extentReportsListener= new ExtentReportsListener();
	RequestSpecification requestSpecification;
	Response response;
	ValidatableResponse validatableresponse;
	
	@Test
	public void getMethod() {
		RestAssured.useRelaxedHTTPSValidation();
		String url="https://reqres.in/api/users";
		RestAssured.baseURI=url;
		RestAssured.given()
				.queryParam("page", "2").contentType("application/json")
				.when().get()
				.then().log().all()
				.assertThat().statusCode(200)
				.assertThat().statusLine("HTTP/1.1 200 OK")
				.assertThat().header("content-type", "application/json; charset=utf-8")
				.header("Connection", "keep-alive")
				.assertThat().body("page", equalTo(2));
		//print the response
		Response res=RestAssured.get(url);
		System.out.println(res.asString());	
	}
	
	@Test
	public void postMethod()
	{
		String url="https://reqres.in/api/users";
		RestAssured.useRelaxedHTTPSValidation();
		String jsonString="{\"name\":\"Gayathri\",\"job\":\"Senior Tester\"}";
		RestAssured.given()
				.baseUri(url)
				.contentType(ContentType.JSON)
				.body(jsonString)
				.when().post()
				.then().assertThat()
				.statusCode(201)
				.body("name", Matchers.is("Gayathri"))
				.body("job", Matchers.is("Senior Tester"))
				.body("createdAt", Matchers.startsWith("2024-04-20"));			
	}
	
	@Test
	public void putMethod()
	{
		String url="https://reqres.in/api/users/2";
		File putData= new File("C:\\Users\\269672\\eclipse-workspace\\ApiTesting\\src\\test\\resources\\payload\\putData.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
				.baseUri(url)
				.contentType(ContentType.JSON)
				.body(putData)
				.when().put()
				.then().assertThat()
				.statusCode(200)
				.body("name", Matchers.is("Gayathri"))
				.body("job", Matchers.is("zion resident"))
				.body("updatedAt", Matchers.startsWith("2024-04-20"));			
	}
	@Test
	public void deleteMethod()
	{
		RestAssured.useRelaxedHTTPSValidation();
		String url="https://reqres.in/api/users";
		RestAssured.baseURI=url;
		RestAssured.given()
				.queryParam("page", "2").contentType("application/json")
				.when().delete()
				.then().log().all()
				.assertThat().statusCode(204);		
	}
}
