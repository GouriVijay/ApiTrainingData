package com.ust.ApiTesting;

import org.testng.ITestListener;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import utilities.ExtentReportsListener;
@Listeners(utilities.ExtentReportsListener.class)

public class RequestSetup implements ITestListener{
	ExtentReportsListener extentReportsListener= new ExtentReportsListener();
	RequestSpecification requestSpecification;
	Response response;
	ValidatableResponse validatableresponse;
	
	@Test
	public void getMethod()
	{
		RestAssured.useRelaxedHTTPSValidation();
		String url="https://reqres.in/";
		RestAssured.baseURI=url;
		Response response= RestAssured
				.given().get("/api/users");
		System.out.println(response.getBody().asString());
	}
}
