package karateTests;

import com.intuit.karate.junit5.Karate;

public class JUnitRunner {
	@Karate.Test
	Karate karateTest() {
		return Karate.run("classpath:karateTests/model.feature").relativeTo(getClass());	
	}

}
