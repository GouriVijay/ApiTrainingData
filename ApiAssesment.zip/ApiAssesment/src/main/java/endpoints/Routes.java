package endpoints;

public class Routes {
	public static String baseUri="";
	public static String get_list="";
	public static String get_byId="";
	public static String post="";
	public static String put="";
	public static String delete="​";
	public static String baseUri_for_schema_validation="";
}
