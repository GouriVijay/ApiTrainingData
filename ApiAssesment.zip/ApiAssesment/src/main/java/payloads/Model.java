package payloads;

public class Model {
	public int id;
    public long idBook;
    public String url;

    public Model() {
    }

    public Model(int id, long idBook, String url) {
        this.id = id;
        this.idBook = idBook;
        this.url = url;
        
    }

    public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getIdBook() {
		return idBook;
	}

	public void setIdBook(long idBook) {
		this.idBook = idBook;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	 @Override
	    public String toString() {
	        return "Model{" +
	                "id=" + id +
	                ", idBook=" + idBook +
	                ", url='" + url + '\'' +
	                '}';
	    }


}
