package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import org.testng.ITestListener;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Usermodel;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class UserTest{

	public Usermodel userPayload;
	
	@BeforeClass
	public void setup() {
		userPayload=new Usermodel(2,"janet.weaver@reqres.in", "janet", "weaver","https://reqres.in/img/faces/2-image.jpg");
	}
	
	@Test
	public void getSingleUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getSingleUser(this.userPayload.getId());
		 response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void getListUsers() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getUserlist(this.userPayload.getId());
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void deleteUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.deleteUser(this.userPayload.getId());
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 204);
	}
	
	@Test
	public void postUser() {
		Usermodel userPayload1=new Usermodel();
		userPayload1=new Usermodel(100,"abc.def@regres.in","abc","def","https://reqres.in/img/faces/3-image.jpg");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.createUser(userPayload1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 201);
	}
	
	@Test
	public void putUser() {
		Usermodel userPayload2=new Usermodel();
		userPayload2=new Usermodel(100,"abc.defg@regres.in","abc","defg","https://reqres.in/img/faces/4-image.jpg");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.updateUser(100, userPayload2);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void patchUser() {
		Usermodel userPayload2=new Usermodel();
		userPayload2=new Usermodel(100,"abc.defg@regres.in","abcc","defg","https://reqres.in/img/faces/4-image.jpg");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.partialUpdateUser(100, userPayload2);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
    public void schemavalidation() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUrii)
	        .when()
	        .get()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\268860\\Desktop\\Java\\ApiTesting1\\sample.json")));
	}
}
