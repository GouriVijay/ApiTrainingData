package endpoints;

public class Routes {
	public static String baseuri="https://fakerestapi.azurewebsites.net";
	public static String get_list="/api/v1/Authors";
	public static String post_author="/api/v1/Authors";
	public static String get_author_book="/api/v1/Authors/authors/books/{bookId}";
	public static String get_author="/api/v1/Authors/{authorId}";
	public static String put_author="/api/v1/Authors/{authorId}";
	public static String delete_author="/api/v1/Authors/{authorId}";
	public static String baseUrii="https://fakerestapi.azurewebsites.net/api/v1/Authors/1";


}
