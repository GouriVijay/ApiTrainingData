package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.Bookmodel;

public class BookEndpoints {

	public static Response getlistOfBooks(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_all_books)
				.queryParam("page", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
	
	public static Response getSingleBook(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_single_book)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
		
	
	public static Response createBook(Bookmodel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.post_book)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}
	
 
	public static Response updateBook(long id, Bookmodel payload) {
		
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.put)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
	
	
	public static Response deleteBook(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.delete)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.delete();
		return response;	
	}
		
}
