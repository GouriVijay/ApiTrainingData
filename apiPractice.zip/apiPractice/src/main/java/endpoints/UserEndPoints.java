package endpoints;

import payloads.AuthorModel;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
//create to perform CRUD operations in user api
public class UserEndPoints {

	public static Response createUser(AuthorModel payload) {
		Response response = RestAssured.given()
				.headers(

						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.post_author)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}
	public static Response getAuthor(long id) {
		Response response = RestAssured.given()
				.headers(

						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.get_author)
				.pathParam("authorId", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}



	public static Response getAuthorBook(long id) {
		Response response = RestAssured.given()
				.headers(

						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.get_author_book)
				.pathParam("bookId", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}	



	public static Response getAll(long id) {
		Response response = RestAssured.given()
				.headers(

						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.get_list)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}


	public static Response deleteAuthor(long id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.delete_author)
				.pathParam("authorId", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.delete();
		return response;
	}
	public static Response updateUser(long id,AuthorModel payload) {
		Response response = RestAssured.given()
				.headers(

						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.put_author)
				.pathParam("authorId", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;
	}
}



