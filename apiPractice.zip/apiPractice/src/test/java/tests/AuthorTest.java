package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import org.testng.ITestListener;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.UserEndPoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.AuthorModel;

public class AuthorTest{

	public AuthorModel authorPayload;
	
	@BeforeClass
	public void setup() {
		authorPayload=new AuthorModel(1,1,"First Name 1","Last Name 1");
	}
	
	@Test
	public void getAuthor() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getAuthor(this.authorPayload.getId());
		 response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void getAuthorBook() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getAuthorBook(this.authorPayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void getAll() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getAll(this.authorPayload.getId());
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void deleteAuthor() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.deleteAuthor(this.authorPayload.getId());
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void createAuthor() {
		AuthorModel authorPayload1=new AuthorModel();
		authorPayload1=new AuthorModel(10,2,"First Name 1","Last Name 0");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.createUser(authorPayload1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void UpdateUser() {
		AuthorModel authorPayload2=new AuthorModel();
		authorPayload2=new AuthorModel(10,2,"First Name 1","Last Name 0");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.updateUser(10, authorPayload2);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	

	
	@Test
    public void schemavalidation() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUrii)
	        .when()
	        .get()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\269657\\APItesting\\apiPractice\\src\\test\\resources\\payload\\sample.json")));
	}
}

