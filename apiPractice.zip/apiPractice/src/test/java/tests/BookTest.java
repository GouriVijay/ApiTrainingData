package tests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.BookEndpoints;
import endpoints.Routes;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Bookmodel;

@Listeners(utilities.ExtentReportsListener.class)
public class BookTest{

	public Bookmodel bookPayload;
	
	@BeforeClass
	public void setup() {
		bookPayload=new Bookmodel(2,"Book 2", "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\\n", 200,"Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n","2024-04-30T06:20:56.6305035+00:00");
	}
	
	@Test
	public void getSingleBook() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BookEndpoints.getSingleBook(this.bookPayload.getId());
		 response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void getListOfBooks() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BookEndpoints.getlistOfBooks(this.bookPayload.getId());
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void deleteBook() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BookEndpoints.deleteBook(this.bookPayload.getId());
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void postBook() {
		Bookmodel bookPayload1=new Bookmodel();
		bookPayload1=new Bookmodel(100,"harry potter","Lorem lorem lorem. Lorem lorem lorem.",300,"Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\\nLorem lorem lorem. Lorem lorem lorem.","2024-05-02");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BookEndpoints.createBook(bookPayload1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void putBook() {
		Bookmodel bookPayload2=new Bookmodel();
		bookPayload2=new Bookmodel(2,"Book 2", "Lorem lorem lorem.", 200,"desc Lorem lorem lorem.","2024-04-30");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BookEndpoints.updateBook(2, bookPayload2);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	
//	@Test
//    public void schemavalidation() {
//	 RestAssured.useRelaxedHTTPSValidation();
//	    RestAssured.given()
//	    .baseUri(Routes.baseUri_for_schema_validation)
//	        .when()
//	        .get()
//	        .then()
//	        .assertThat()
//	        .body(matchesJsonSchema(new File("C:\\Users\\269672\\APItesting\\ApiPractice\\src\\test\\resources\\payload\\sample.json")));
//	}
}
